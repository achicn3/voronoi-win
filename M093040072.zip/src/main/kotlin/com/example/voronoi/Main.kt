package com.example.voronoi

class Main {
    companion object {
        @JvmStatic
        fun main(args: Array<String>) {
            HelloApplication.main(args)
        }
    }
}